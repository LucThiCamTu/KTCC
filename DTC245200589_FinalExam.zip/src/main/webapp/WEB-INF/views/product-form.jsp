<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><c:out value="${product != null ? 'Cập nhật Sản phẩm' : 'Thêm Sản phẩm Mới'}" /></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="number"] { width: 300px; padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .btn-submit { background-color: #007bff; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; }
        .btn-back { background-color: #6c757d; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>
    <h2><c:out value="${product != null ? 'Chỉnh sửa Sản phẩm' : 'Thêm Sản phẩm Mới'}" /></h2>

    <form action="products" method="post">
        <input type="hidden" name="action" value="${product != null ? 'update' : 'insert'}" />
        <c:if test="${product != null}">
            <input type="hidden" name="id" value="${product.id}" />
        </c:if>

        <div class="form-group">
            <label for="name">Tên sản phẩm:</label>
            <input type="text" id="name" name="name" value="${product != null ? product.name : ''}" required />
        </div>

        <div class="form-group">
            <label for="price">Giá:</label>
            <input type="number" step="0.01" id="price" name="price" value="${product != null ? product.price : ''}" required />
        </div>

        <div class="form-group">
            <label for="quantity">Số lượng:</label>
            <input type="number" id="quantity" name="quantity" value="${product != null ? product.quantity : ''}" required />
        </div>

        <button type="submit" class="btn-submit">Lưu lại</button>
        <a href="products" class="btn-back">Hủy</a>
    </form>
</body>
</html>
